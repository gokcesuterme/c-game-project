//
// Created by gterm on 23.05.2024.
//
/* gökçesu terme 2453587
I read and accept the submission rules and the extra rules specified in each question. This is
my own work that is done by me only */
#include "Food.h"
#include <cmath>
using namespace std;
Food::Food(): Elements(1, 'F', 0, 0) {}
void Food::applyEffect(Player& player, int n) {
    int amount = floor(n / 6.0);
    player.increaseHealth(amount);
}