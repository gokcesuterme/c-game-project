//
// Created by gterm on 23.05.2024.
//
/* gökçesu terme 2453587
I read and accept the submission rules and the extra rules specified in each question. This is
my own work that is done by me only */
#include <iostream>
using namespace std;
#include "Player.h"
Player::Player(int n, int id) {
    health = float(n * 2); score = 0; player_id = id;
    gatheredItems[0] = 0; gatheredItems[1]=0; //each collected item is 0 in the begging
    goldBonus = 0; woodBonus = 0;
}

Player::~Player() {}
int Player:: getScore() {
    return score;
}
float Player::getHealth() {
    return health;
}

void Player::increaseHealth(const float amount) {
    health += amount;
}
void Player::decreaseHealth(const float amount) {
    health -= amount;
    if(health<0) {
        health = 0;
    }
}
void Player::increaseScore(const int amount) {
    score += amount;
}
void Player::addElement(char item) {
    if (item == 'G') {
        gatheredItems[0]++;  // Increment gold count
    } else if (item == 'I') {
        gatheredItems[1]++;  // Increment wood count
    }
}

void Player::displayStatus() const {
    cout << "Player " << player_id << ": Health = " << health << ", Score = " << score << endl;
    cout << "Gold = " << gatheredItems[0] << ", Wood = " << gatheredItems[1] << endl;
}
void Player::checkBonusHealth(int n) {
    if(gatheredItems[0] > goldBonus && gatheredItems[0] %3 == 0) {
        cout<<"3 golds collected bonus health will be added!"<<endl;
        increaseHealth(n / 4);
        goldBonus = gatheredItems[0];
    }
    if(gatheredItems[1] % 2 == 0 && gatheredItems[1]> woodBonus) {
        cout<<"2 woods collected bonus health will be added!" << endl;
        increaseHealth(n / 8);
        woodBonus = gatheredItems[1];
    }
}
int Player::getPlayerId() {
    return player_id;
}



