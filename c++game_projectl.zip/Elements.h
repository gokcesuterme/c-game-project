//
// Created by gterm on 23.05.2024.
//
/* gökçesu terme 2453587
I read and accept the submission rules and the extra rules specified in each question. This is
my own work that is done by me only */
#ifndef ELEMENTS_H
#define ELEMENTS_H
#include "Player.h"
class Elements {
private:
    int size;
    char symbol;
    int health_points; //wood,medical,food, - for animals
    int score_points; //for gold
public:
    Elements(int sz, char symbl, int hp, int sp);
    virtual ~Elements() = default;
    int getSize();
    virtual char getSymbol() const = 0;
    int getHealthPoints();
    int getScorePoints();
    virtual void applyEffect(Player& player,int n) = 0;

};

#endif //ELEMENTS_H
