/* gökçesu terme 2453587
I read and accept the submission rules and the extra rules specified in each question. This is
my own work that is done by me only */
//
// Created by gterm on 23.05.2024.
//

#ifndef MEDICAL_H
#define MEDICAL_H
#include "Elements.h"
class Medical:public Elements{
public:
    Medical();
    void applyEffect(Player& player, int n) override;
    char getSymbol() const override { return 'S'; }
    ~Medical() override = default;
};

#endif //MEDICAL_H
