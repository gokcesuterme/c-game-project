//
// Created by gterm on 23.05.2024.
//
/* gökçesu terme 2453587
I read and accept the submission rules and the extra rules specified in each question. This is
my own work that is done by me only */
#ifndef PLAYER_H
#define PLAYER_H
#include <vector>
using namespace std;
class Player {
private:
    int player_id;
    float health;
    int score; // num of golds collected
    int gatheredItems[2]; // 0 for gold 1 for wood
    int goldBonus;
    int woodBonus;
public:
    Player(int n, int id);
    ~Player();
    int getScore();
    float getHealth();
    void increaseHealth(const float amount);
    void decreaseHealth(const float amount);
    void increaseScore(const int amount);
    void addElement(char item);
    void displayStatus()const;
    void checkBonusHealth(int n);
    int getPlayerId();
};

#endif //PLAYER_H
