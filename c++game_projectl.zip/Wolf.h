//
// Created by gterm on 23.05.2024.
//
/* gökçesu terme 2453587
I read and accept the submission rules and the extra rules specified in each question. This is
my own work that is done by me only */

#ifndef WOLF_H
#define WOLF_H
#include "WildAnimal.h"

class Wolf : public WildAnimal{
public:
    Wolf();
    void applyEffect(Player& player, int n) override;
    char getSymbol() const override { return 'W'; }
    ~Wolf() override = default;
};

#endif //WOLF_H
