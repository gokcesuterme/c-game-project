//
// Created by gterm on 23.05.2024.
//
/* gökçesu terme 2453587
I read and accept the submission rules and the extra rules specified in each question. This is
my own work that is done by me only */

#ifndef WILDANIMAL_H
#define WILDANIMAL_H
#include "Elements.h"


class WildAnimal: public Elements {
public:
    WildAnimal(int sz, char symbl, int hp);
    virtual ~WildAnimal() = default;
    virtual char getSymbol() const = 0;
    virtual void applyEffect(Player& player, int n) override = 0;


};



#endif //WILDANIMAL_H
