/* gökçesu terme 2453587
I read and accept the submission rules and the extra rules specified in each question. This is
my own work that is done by me only */
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <cmath>
#include "Grid.h"
#include "Player.h"
using namespace std;
class Game {
public:
    int rounds(int n) {
        return rand() % (n * n - 20 + 1) + 20;
    }
    int diceRoll() {
        cout << "guess even (e) or odd(o): ";
        char guess;
        cin >> guess;

        int diceNum = rand() % 100 + 1;
        bool isEven = (diceNum  % 2 == 0);
        if ((guess == 'e' && isEven) || (guess == 'o' && !isEven)) {
            cout << "Correct guess! You escaped." << endl;
            return 1;
        } else {
            cout << "Wrong guess!" << endl;
            return 0;
        }
    }

    void startGame(int n) {
        int diceResult;
        srand(time(nullptr));

        // Initialize grid
        Grid gameGrid(n);

        // Display the grid
        cout << "Initial game grid:" << endl;
        gameGrid.displayGrid();

        // Initialize players
        Player p1(n, 1);
        Player p2(n, 2);
        cout << "Players' initial statuses:" << endl;
        p1.displayStatus();
        p2.displayStatus();

        int game_rounds = rounds(n);
        cout << "The game will be played in total " << game_rounds << " rounds" << endl;
        //game loop
        for(int i = 0 ; i<game_rounds; i++) {
            //cout<<"dd"<<endl;
            cout << "\nRound " << i + 1 << ":" << endl;
            gameGrid.displayPlayerGrid();
            Player& currentPlayer = (i % 2 == 0) ? p1 : p2; // p1 for even index p2 for odd index. p1 start first
            int x, y;
            do {
                cout << "Player " << currentPlayer.getPlayerId() << ", enter coordinates (x y): ";
                cin >> x >> y;

                if (gameGrid.isVisited(x, y)) {
                    cout << "This cell has been visited. Please enter new coordinates." << endl;
                }

            } while (gameGrid.isVisited(x, y));

            gameGrid.markVisited(x, y);
            // Check if coordinates are in boundry
            if (x >= 0 && x < n && y >= 0 && y < n) {
                char elemType = gameGrid.getElementSymbolAt(x, y);
                cout << "cell contains the elem: " << elemType << endl;
                switch (elemType) {

                    ////size logic dont forget
                    case 'I': // element wood
                    gameGrid.getElementAt(x, y)->applyEffect(currentPlayer, n);

                        currentPlayer.addElement('I');
                    break;

                    case 'G': //element gold
                        gameGrid.getElementAt(x, y)->applyEffect(currentPlayer, n);
                        currentPlayer.addElement('G');
                    break;

                    case 'S': //element emdical supply
                        gameGrid.getElementAt(x, y)->applyEffect(currentPlayer, n);
                    break;

                    case 'F': //element food supply
                        gameGrid.getElementAt(x, y)->applyEffect(currentPlayer, n);
                    break;

                    case 'W': //elem wolf
                        diceResult=diceRoll();
                        if(diceResult==0) {
                            gameGrid.getElementAt(x, y)->applyEffect(currentPlayer, n);
                        }

                    break;

                    case 'B': //elem beear
                        diceResult = diceRoll();
                        if(diceResult==0) {
                        gameGrid.getElementAt(x, y)->applyEffect(currentPlayer, n);
                         }
                    break;

                    case '.':
                        cout << "Empty cell." << endl;
                    break;
                }
                currentPlayer.checkBonusHealth(n);

            } else {
                cout << "Invalid coordinates. enter again" << endl;
                i--;
                continue;
            }

            currentPlayer.displayStatus();
            //when both dies game ends
            if(i==game_rounds-1) {
                cout<<"All rounds completed. Gmae ends"<<endl;

            }
            if(p1.getHealth()==0 && p2.getHealth()==0) {
                cout<<"Game Ends! both players died"<<endl;
                i=game_rounds;
            }
            //when all the golds are collected.
            int totalGold = floor(2*(n * n) / 25.0);
            //cout<<"total gold"<<totalGold<<endl;
            int collectedGoldP1= p1.getScore()/100;
            int collectedGoldP2= p2.getScore()/100;
            if(collectedGoldP1+collectedGoldP2 == totalGold) {
                cout<<"Game Ends! All golds are collected"<<endl;
                i = game_rounds;
            }
        }
        cout<< "The both players status are:"<<endl;
        p1.displayStatus();
        p2.displayStatus();
        if(p1.getScore()>p2.getScore()) {
            cout<<"Player 1 wins"<<endl;
        }
        else if (p1.getScore()<p2.getScore()) {
            cout<<"Player 2 wins"<<endl;

        }
        else {
            cout<<"its a tie."<<endl;
        }

    }
};

int main() {
    Game game;
    int n; // for board size
    cout << "Enter a number (min 5) to create the game Grid --> " << endl;
    cin >> n;

    if (n < 5) {
        cout << "Grid size must be at least 5. Setting grid size to 5." << endl;
        n = 5;
    }
    game.startGame(n);

    return 0;
}
