/* gökçesu terme 2453587
I read and accept the submission rules and the extra rules specified in each question. This is
my own work that is done by me only */
//
// Created by gterm on 23.05.2024.
//
#include "Medical.h"
#include <cmath>
Medical::Medical(): Elements(1, 'S', 0, 0) {}
void Medical::applyEffect(Player& player, int n) {
    int amount = floor(n / 6.0);
    player.increaseHealth(amount);
}