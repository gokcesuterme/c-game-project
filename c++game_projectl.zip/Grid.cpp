/* gökçesu terme 2453587
I read and accept the submission rules and the extra rules specified in each question. This is
my own work that is done by me only */
#include "Grid.h"
#include "Food.h"
#include "Wood.h"
#include "Medical.h"
#include "Gold.h"
#include "Bear.h"
#include "Wolf.h"
#include <iostream>
#include <cstdlib>
#include <ctime>
#include <cmath>
using namespace  std;

Grid::Grid(int n) : size(n), board(n, vector<Elements*>(n, nullptr)), playerGrid(n, vector<char>(n, '.')) {
    srand(time(nullptr));
    cout << "Initializing playerGrid" <<endl;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            playerGrid[i][j] = '.';  //all unvisited in the begiing.
        }
    }
    cout << "Deploying elements" << endl;
    deployElements();
    cout << "Grid initialized successfully." << endl;
}
Grid::~Grid() {
    for (int i = 0; i < size; ++i) {
        for (int j = 0; j < size; ++j) {
            delete board[i][j];
        }
    }
}

int Grid::getSize() const {
    return size;
}

void Grid::displayGrid() const {
    for (const vector<Elements*>& row : board) {
        for (const Elements* cell : row) {
            if (cell == nullptr) {
                cout << ". ";
            } else {
                cout << cell->getSymbol() << " ";
            }
        }
        cout << endl;
    }
}

bool Grid::canPlaceElement(int x, int y, int elementSize, int direction) const {
    for (int i = 0; i < elementSize; ++i) {
        int nx = x, ny = y;
        if (direction == 0) nx += i;        // Vertical
        else if (direction == 1) ny += i;   // Horizontal
        else if (direction == 2) { nx += i; ny += i; } // Diagonal

        if (nx >= size || ny >= size || board[nx][ny] != nullptr) {
            return false;
        }
    }
    return true;
}

void Grid::placeElement(Elements* element, int x, int y, int elementSize, int direction) {
    for (int i = 0; i < elementSize; ++i) {
        int nx = x, ny = y;
        if (direction == 0) nx += i;        // Vertical
        else if (direction == 1) ny += i;   // Horizontal
        else if (direction == 2) { nx += i; ny += i; } // Diagonal

        board[nx][ny] = element;
    }
}

void Grid::deployElements() {
    int numElements = floor((size * size) / 25.0);

    for (int i = 0; i < 2 * numElements; ++i) {
        int x, y;
        do {
            x = rand() % size;
            y = rand() % size;
        } while (board[x][y] != nullptr);
        placeElement(new Food(), x, y, 1, 0);

        do {
            x = rand() % size;
            y = rand() % size;
        } while (board[x][y] != nullptr);
        placeElement(new Wood(), x, y, 2, rand() % 3);

        do {
            x = rand() % size;
            y = rand() % size;
        } while (board[x][y] != nullptr);
        placeElement(new Medical(), x, y, 1, 0);

        do {
            x = rand() % size;
            y = rand() % size;
        } while (board[x][y] != nullptr);
        placeElement(new Gold(), x, y, 1, 0);

        do {
            x = rand() % size;
            y = rand() % size;
        } while (board[x][y] != nullptr);
        placeElement(new Wolf(), x, y, 1, 0);
    }

    // Place bears
    for (int i = 0; i < numElements; ++i) {
        int direction = rand() % 3;
        int x, y;

        do {
            x = rand() % size;
            y = rand() % size;
        } while (!canPlaceElement(x, y, 3, direction));

        placeElement(new Bear(), x, y, 3, direction);
    }
}

Elements* Grid::getElementAt(int x, int y) const {
    if (x >= 0 && x < size && y >= 0 && y < size) {
        return board[x][y];
    }
    return nullptr;
}
char Grid::getElementSymbolAt(int x, int y) const {
    if (x >= 0 && x < size && y >= 0 && y < size && board[x][y] != nullptr) {
        return board[x][y]->getSymbol();  // symbol
    }
    return '.';  // emppty cell
}
void Grid::displayPlayerGrid() const {
    for (const vector<char>& row : playerGrid) {
        for (const char& cell : row) {
            cout << cell << " ";  //put x for visited . for unvisittied
        }
        cout << endl;
    }
}
bool Grid::isVisited(int x, int y) const {
    if (x >= 0 && x < size && y >= 0 && y < size) {
        return playerGrid[x][y] == 'X';
    }
    return true;
}

void Grid::markVisited(int x, int y) {
    if (x >= 0 && x < size && y >= 0 && y < size) {
        playerGrid[x][y] = 'X';
    }
}