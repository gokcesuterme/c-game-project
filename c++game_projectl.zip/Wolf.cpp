//
// Created by gterm on 23.05.2024.
//
/* gökçesu terme 2453587
I read and accept the submission rules and the extra rules specified in each question. This is
my own work that is done by me only */
#include "Wolf.h"
#include <cmath>
using namespace std;
Wolf::Wolf() : WildAnimal(1, 'W', 0) {}
void Wolf::applyEffect(Player& player, int n) {
    int amount = floor(n / 4.0);
    player.decreaseHealth(amount);
}
