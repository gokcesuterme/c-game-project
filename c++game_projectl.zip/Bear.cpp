//
// Created by gterm on 23.05.2024.
//
/* gökçesu terme 2453587
I read and accept the submission rules and the extra rules specified in each question. This is
my own work that is done by me only */
#include <cmath>
#include "Bear.h"
Bear::Bear() : WildAnimal(3, 'B', 0) {}

void Bear::applyEffect(Player& player, int n) {
    int amount = std::floor(n / 2.0);
    player.decreaseHealth(amount);
}
