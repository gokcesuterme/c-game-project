//
// Created by gterm on 23.05.2024.
//
/* gökçesu terme 2453587
I read and accept the submission rules and the extra rules specified in each question. This is
my own work that is done by me only */
#ifndef FOOD_H
#define FOOD_H
#include "Elements.h"
class Food: public Elements{
public:
    Food();
    void applyEffect(Player& player, int n) override;
    char getSymbol() const override { return 'F'; }
    ~Food() override = default;
};
#endif //FOOD_H
