/* gökçesu terme 2453587
I read and accept the submission rules and the extra rules specified in each question. This is
my own work that is done by me only */
#ifndef GRID_H
#define GRID_H

#include <vector>
#include "Elements.h"

class Grid {
private:
    int size;
    vector<std::vector<Elements*>> board;
    vector<std::vector<char>> playerGrid;
    vector<std::vector<bool>> visited;

    bool canPlaceElement(int x, int y, int size, int direction) const;
    void placeElement(Elements* element, int x, int y, int size, int direction);

public:
    Grid(int n);
    ~Grid();

    int getSize() const;
    void displayGrid() const;
    void deployElements();
    char getElementSymbolAt(int x, int y) const;
    Elements* getElementAt(int x, int y) const;
    void displayPlayerGrid() const;
    bool isVisited(int x, int y) const;
    void markVisited(int x, int y);
};

#endif // GRID_H
