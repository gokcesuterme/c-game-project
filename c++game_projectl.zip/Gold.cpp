//
// Created by gterm on 23.05.2024.
//
/* gökçesu terme 2453587
I read and accept the submission rules and the extra rules specified in each question. This is
my own work that is done by me only */
#include "Gold.h"
#include <cmath>
Gold::Gold(): Elements(1, 'G', 0, 0) {}
void Gold::applyEffect(Player& player,int n){
    player.increaseScore(100);
}
