//
// Created by gterm on 23.05.2024.
//
/* gökçesu terme 2453587
I read and accept the submission rules and the extra rules specified in each question. This is
my own work that is done by me only */
#include "Elements.h"
Elements::Elements(int sz, char symbl, int hp, int sp) {
    size =sz;
    symbol =symbl;
    health_points = hp;
    score_points =sp;
}

int Elements::getSize() {
    return size;
}
int Elements::getHealthPoints() {
    return health_points;
}
int Elements::getScorePoints() {
    return score_points;
}


